from bs4 import BeautifulSoup
from urllib.parse import urlparse

def baca_html_dari_file(nama_file):
    with open(nama_file, 'r') as file:
        return file.read()

nama_file_html = 'x2'

html_code = baca_html_dari_file(nama_file_html)

soup = BeautifulSoup(html_code, 'html.parser')

link_tags = soup.find_all('a', jsname='UWckNb')

domains = set()  

for link_tag in link_tags:
    link = link_tag['href']
    parsed_link = urlparse(link)
    domain = parsed_link.netloc
    full_domain = "http://" + domain
    domains.add(full_domain)

# Menyimpan hasil ke file d2.txt
with open('gsearch', 'w') as file:
    for domain in domains:
        file.write(domain + '\n')

if not link_tags:
    print("Tidak ada tag <a> dengan class EZAeBe dalam HTML.")
