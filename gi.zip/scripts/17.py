import time
import re

banner = """ 
Mass Add HTTP (Premium Leakers)
"""
print(banner)

expiry_date = "2029-02-21"

def check_expiry():
    current_date = time.strftime("%Y-%m-%d")
    if current_date > expiry_date:
        print("🚀 Lisensi Anda telah kedaluwarsa.")
        print(f"🚀 Silakan lakukan pembayaran sebesar Rp.1.000.000 contact @biskuat15 untuk memperpanjang license anda.")
        print("🚀 Anda memiliki 7 hari untuk melakukan pembayaran.")
        return False
    return True

def add_http(url):
    try:
        https = 'http://' + url
        with open('http.txt', 'a', encoding='utf-8') as f:
            f.write(https + '\n')
        print(https)
    except Exception as e:
        print(f"Error adding http: {e}")

def remove_http(url):
    try:
        url_without_http = url.replace('http://', '')
        with open('http_removed.txt', 'a', encoding='utf-8') as f:
            f.write(url_without_http + '\n')
        print(url_without_http)
    except Exception as e:
        print(f"Error removing http: {e}")

def url_cleaner(url):
    try:
        clean_url = re.sub(r'(https?://)?(www\.)?', '', url.strip().lower())
        clean_url = re.sub(r'/.*$', '', clean_url)
        clean_url = 'https://' + clean_url
        with open('cleaned_urls.txt', 'a', encoding='utf-8') as f:
            f.write(clean_url + '\n')
        print(clean_url)
    except Exception as e:
        print(f"Error cleaning URL: {e}")

def process_urls(action, urls):
    for url in urls:
        clean_url = url.strip()
        if action == 1:
            add_http(clean_url)
        elif action == 2:
            remove_http(clean_url)
        elif action == 3:
            url_cleaner(clean_url)
        else:
            print("Invalid action")

if __name__ == "__main__":
    if not check_expiry():
        exit()
    
    site = input('List Site : ')
    action = int(input('[1] - Add HTTP\n[2] - Remove HTTP\n[3] - Url Cleaner\nChoose action: '))
    try:
        with open(site, 'r', encoding='utf-8') as f:
            urls = f.readlines()
        process_urls(action, urls)
    except FileNotFoundError:
        print(f"File {site} not found.")
    except UnicodeDecodeError:
        print(f"Could not decode file {site}. Please ensure it is encoded in UTF-8.")
