import requests
import urllib3
import os
import random
import sys
import time
import subprocess
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore

init()
urllib3.disable_warnings()

# Now regular ANSI codes should work, even in Windows
RED = Fore.RED
RESET = Fore.RESET
WHITE = Fore.WHITE
GREEN = Fore.GREEN  # Added green color

def print_logo():
    clear = "\x1b[0m"
    colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]

    x = """

            FILTER BUGS (ACTIVE)
            BY CHAELTHEEX3C
                           
                          
                                                        
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.02)

print_logo()

if not os.path.exists("result3/"):
    os.makedirs("result3/", 0o755)

def filterBugs(site):
    site = site.strip()
    tmpdomain = f"tmp/httpx.txt"
    httpxcmd = ["httpx", "-u", site, "-sc", "-title", "-bp", "-ct", "-cl", "-fr", "-timeout", "30", "-o", tmpdomain, "-j", "-silent"]

    process = subprocess.run(httpxcmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    if process.returncode == 0:
        try:
            with open(tmpdomain, "r") as tmpdomain_file:
                for line in tmpdomain_file:
                    # print(line)
                    if '\"status_code\":200' in line:
                        print("[+] BUG :: " + site)
                        with open('result3/Bugs.txt', 'a') as bug_file:
                            bug_file.write(site + '\n')
                    elif "404" in line:
                        print("[+] 404 :: " + site)
                    else:
                        print("[+] ?? :: " + site)
                        with open('result3/ntah.txt', 'a') as ntah_file:
                            ntah_file.write(site + '\n')
        finally:
            os.remove(tmpdomain)
    else:
        if os.path.exists(tmpdomain):
            os.remove(tmpdomain)
        print("Failed to execute command!!")


def multixcms():
    sitex = open(input(RED + 'List : ' + WHITE), 'r').readlines()
    td = input("Threads : ")  
    pool = ThreadPool(int(td))
    pool.map(filterBugs, sitex)
    pool.close()
    pool.join()

multixcms()
