import requests
import subprocess
import urllib3
import os
import random
import sys
import time
from bs4 import BeautifulSoup
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore

init()
urllib3.disable_warnings()

RED = Fore.RED
RESET = Fore.RESET
WHITE = Fore.WHITE
GREEN = Fore.GREEN

def print_logo():
    clear = "\x1b[0m"
    colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]

    x = """

            FILTER BUGS (ACTIVE)
            BY CHAELTHEEX3C
                           
                          
                                                        
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.02)

print_logo()

if not os.path.exists("result4/"):
    os.makedirs("result4/", 0o755)

header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

def lightxcms(site):
    site = site.strip()
    site = site.replace('\n', '').replace('\r', '')

    try:
        payload = requests.get(site, headers=header, timeout=30, allow_redirects=True, verify=False)
        payload.raise_for_status()
        soup = BeautifulSoup(payload.text, 'html.parser')
        title = soup.title.string if soup.title else f"{RED}No title found{RESET}"
        print(site + '   [' + f"{GREEN}{title}{RESET}" + ']')
    except Exception as e:
        print(RED + "[+] DEAD SITE :: " + site + " (" + str(e) + ")" + RESET)
def multixcms():
    sitex = open(input(RED + 'List : ' + WHITE), 'r').readlines()
    td = input("Threads : ")  
    pool = ThreadPool(int(td))
    pool.map(lightxcms, sitex)
    pool.close()
    pool.join()

multixcms()