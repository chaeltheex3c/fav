import requests
import subprocess
import urllib3
import os
import random
import sys
import time
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore

init()
urllib3.disable_warnings()

# Now regular ANSI codes should work, even in Windows
RED = Fore.RED
RESET = Fore.RESET
WHITE = Fore.WHITE
GREEN = Fore.GREEN  # Added green color

def print_logo():
    clear = "\x1b[0m"
    colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]

    x = """

            FILTER BUGS (ACTIVE)
            BY CHAELTHEEX3C
                           
                          
                                                        
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.02)

print_logo()

if not os.path.exists("result2/"):
    os.makedirs("result2/", 0o755)

if not os.path.exists("result/"):
    os.makedirs("result/", 0o755)

header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

def first(site):
    site.strip()
    site = site.replace('\n', '').replace('\r', '')

    admins = [  "/admin",
                "/adm",
                "/backend",
                "/panel",
                "/cms",
                "/administrator",
                "/administration",
                "/backoffice",
                "/back",
                "/dashboard",
                "/user",
                "/login",
                "/admin1",
                "/admin2",
                "/amministrazione",
                "/gestion",
                "/area",
                "/areas",
                "/master",
                "/manager"
        ]
    
    paths = [
            'elfinder',
            'elFinder',
            'connectors',
            'kcfinder',
            'kcf',
            'kcfinder-2.51',
            'kcfinder-2.51',
            'kcfinder_2.51',
            'kcfinder_2.51',
            'kcfinder_2',
            'kcfinder_2',
            'kcfinder_',
            'kcfinder__',
            'kcfinder___',
            'kcfinder_1',
            'kcfinder_2',
            'kcfinder_3',
            'kcfinder1',
            'kcfinder1.0',
            '_kcfinder',
            '__kcfinder',
            '___kcfinder',
            'kcfinder2',
            'kcfinder2.0',
            '_kcfinder',
            '__kcfinder',
            '___kcfinder',
            'kcfinder3',
            'kcfinder3.0',
            '_kcfinder',
            '__kcfinder',
            '___kcfinder',
            'kcfinder1',
            'kcfinder251',
            'kcfinder2.51',
            'filemanager',
            'responsive_filemanager',
            'fileman',
            'fm',
            'file-manager',
            'file_manager',
            'pgrfilemanager',
            'moxiemanager',
            'tinybrowser',
            'kfm',
            'imagemanager',
            'openmanager',
            'zfilemanager',
            'zfileman',
            'fckeditor',
            'doksoft_uploader',
            'ajaxfilemanager',
            'AjexFileManager',
            'pdw_file_browser',
            'ajaxfm',
            'uploadify',
            'uploader',
            'blueimp-file-upload',
            'jquery-file-upload',
            'jQuery-File-Upload',
            'jquery-fileupload',
            'fileupload',
            'file-upload',
            'file-uploader',
            'jupload',
            'responsiveFilemanager',
            'responsivefilemanager',
            'ResponsiveFilemanager',
            'responsiveFileManager',
            'responsivefileManager',
            'ResponsiveFileManager',
            'rfm',
            'dropzone',
            'php'
    ]

    bugs = ['.git',
            '.env',
            '/filemanager',
            '/laravel-filemanager',
            'filemanager/dialog.php',
            'fm/dialog.php',
            'responsiveFilemanager/dialog.php',
            'responsivefilemanager/dialog.php',
            'ResponsiveFilemanager/dialog.php',
            'responsiveFileManager/dialog.php',
            'responsivefileManager/dialog.php',
            'ResponsiveFileManager/dialog.php',
            'rfm/dialog.php',
            'responsive_filemanager/dialog.php',
            'file-manager/dialog.php',
            'file_manager/dialog.php',
            'kfm',
            'PGRFileManager.php',
            'pgrfilemanager/php/upload.php',
            'pgrfilemanager/php/files.php',
            'kcfinder/browse.php',
            'kcfinder/upload.php',
            'kcf/upload.php',
            'kcfinder-2.51/upload.php',
            'kcf/browse.php',
            'kcfinder-2.51/browse.php',
            'kcfinder_2.51/browse.php',
            'kcfinder_2.51/upload.php',
            'kcfinder_2/browse.php',
            'kcfinder_2/upload.php',
            'kcfinder_/browse.php',
            'kcfinder__/browse.php',
            'kcfinder___/browse.php',
            'kcfinder_1/browse.php',
            'kcfinder_2/browse.php',
            'kcfinder_3/browse.php',
            'kcfinder1/browse.php',
            'kcfinder1.0/browse.php',
            '_kcfinder/browse.php',
            '__kcfinder/browse.php',
            '___kcfinder/browse.php',
            'kcfinder2/browse.php',
            'kcfinder2.0/browse.php',
            'kcfinder3/browse.php',
            'kcfinder3.0/browse.php',
            'kcfinder251/browse.php',
            'connectors/uploadtest.html',
            'connectors/test.html',
            'server/php',
            'server/php/',
            'server/php/index.php',
            'moxiemanager',
            'moxiemanager/index.php',
            'fileman/index.html',
            'fileman/FileManager.aspx',
            'openmanager',
            'openmanager/index.php',
            'ckeditor/config.js',
            'ckeditor1/config.js',
            'ckeditor2/config.js',
            'ckeditor3/config.js',
            'ckeditor4/config.js',
            'ckeditor5/config.js',
            '_ckeditor/config.js',
            '__ckeditor/config.js',
            '___ckeditor/config.js',
            'doksoft_uploader/uploader.php',
            'elfinder/php/connector.php',
            'elfinder/php/connector.minimal.php',
            'elfinder/php/connector_minimal.php',
            'elFinder/php/connector.php',
            'elFinder/php/connector.minimal.php',
            'elFinder/php/connector_minimal.php',
            'elfinder/connectors/php/connector.php',
            'elfinder/connectors/php/connector.minimal.php',
            'elfinder/connectors/php/connector_minimal.php',
            'elFinder/connectors/php/connector.php',
            'elFinder/connectors/php/connector.minimal.php',
            'elFinder/connectors/php/connector_minimal.php',
            'elfinder/connector.php',
            'elfinder/connector.minimal.php',
            'elfinder/connector_minimal.php',
            'elFinder/connector.php',
            'elFinder/connector.minimal.php',
            'elFinder/connector_minimal.php',
            '/php/connector.php',
            'elfinder.html',
            'elFinder.html',
            'elfinder.php',
            'elFinder.php',
            '/elfinder',
            '/elFinder',
            'elfinder/ckeditor',
            'elFinder/ckeditor',
            'elfinder-ckeditor',
            'elFinder-ckeditor',
            'PHP/eval-stdin.php',
            'inc/data.php',
            'AjexFileManager',
            'AjexFileManager/index.html',
            'fm/index.html',
            'im/index.html',
            'im',
            'fm',
            'fileman',
            'php',
            'html',
            'phtml',
            'aspx',
            'Util/PHP/eval-stdin.php'
            ]
    
    if any(site.endswith(endpoint) for endpoint in bugs):
        print("[+] BUG :: " + site)
        open('result2/bugs.txt', 'a').write(site+'\n')
    elif any(site.endswith(admin) for admin in admins):
        print("[+] ADMIN :: " + site)
        open('result2/bugs.txt', 'a').write(site+'\n')
    elif any(site.endswith(bugPath) for bugPath in paths):
        print("[+] BUG PATH :: " + site)
        open('result2/bugs.txt', 'a').write(site+'\n')

def secc(site):
    site = site.strip()
    site = site.replace('\n', '').replace('\r', '').replace(' ', '')

    pathAdmin = [  "/admin",
                "/adm",
                "/backend",
                "/panel",
                "/cms",
                "/administrator",
                "/administration",
                "/backoffice",
                "/back",
                "/user",
                "/admin1",
                "/admin2",
                "/amministrazione",
                "/gestion",
                "/area",
                "/areas",
                "/master",
                "/manager"
        ]

    paths = [
            'elfinder',
            'elFinder',
            'connectors',
            'kcfinder',
            'kcf',
            'kcfinder-2.51',
            'kcfinder-2.51',
            'kcfinder_2.51',
            'kcfinder_2.51',
            'kcfinder_2',
            'kcfinder_2',
            'kcfinder_',
            'kcfinder__',
            'kcfinder___',
            'kcfinder_1',
            'kcfinder_2',
            'kcfinder_3',
            'kcfinder1',
            'kcfinder1.0',
            '_kcfinder',
            '__kcfinder',
            '___kcfinder',
            'kcfinder2',
            'kcfinder2.0',
            '_kcfinder',
            '__kcfinder',
            '___kcfinder',
            'kcfinder3',
            'kcfinder3.0',
            '_kcfinder',
            '__kcfinder',
            '___kcfinder',
            'kcfinder1',
            'kcfinder251',
            'kcfinder2.51',
            'filemanager',
            'responsive_filemanager',
            'fileman',
            'fm',
            'file-manager',
            'file_manager',
            'pgrfilemanager',
            'moxiemanager',
            'tinybrowser',
            'kfm',
            'imagemanager',
            'openmanager',
            'zfilemanager',
            'zfileman',
            'fckeditor',
            'doksoft_uploader',
            'ajaxfilemanager',
            'AjexFileManager',
            'pdw_file_browser',
            'ajaxfm',
            'uploadify',
            'uploader',
            'blueimp-file-upload',
            'jquery-file-upload',
            'jQuery-File-Upload',
            'jquery-fileupload',
            'fileupload',
            'file-upload',
            'file-uploader',
            'jupload',
            'responsiveFilemanager',
            'responsivefilemanager',
            'ResponsiveFilemanager',
            'responsiveFileManager',
            'responsivefileManager',
            'ResponsiveFileManager',
            'rfm',
            'dropzone',
            'php']

    try:
        payload = requests.get(site, headers=header, timeout=30, allow_redirects=True, verify=False)
        if payload.status_code == 200:
            notFound = ['404', 'not found', 'Not Found', 'Error']
            if any(notF not in payload.text for notF in notFound):
                if "<title>FileManager</title>" in payload.text:
                    print("[+] RFM1 :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif "<title>Responsive FileManager</title>" in payload.text:
                    print("[+] RFM2 :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif 'KCFinder:' in payload.text:
                    print("[+] KCFinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif 'open_manager_upload_path' in payload.text:
                    print("[+] OpenManager :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '{"files' in payload.text:
                    print("[+] JFU :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '<title>FCKeditor -' in payload.text:
                    print("[+] FCKeditor :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '<pre>Array' in payload.text:
                    print("[+] Ajax File Manager :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '<title>Ajax File Manager' in payload.text:
                    print("[+] Ajax File Manager :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '{"error":["errUnknownCmd' in payload.text:
                    print("[+] elfinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif "url : '/efconnect'" in payload.text:
                    print("[+] elfinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '<title>elFinder' in payload.text:
                    print("[+] elfinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif "url: 'php/connector_minimal.php'" in payload.text:
                    print("[+] elfinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif "url: 'php/connector.minimal.php'" in payload.text:
                    print("[+] elfinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif "url : 'php/connector.php'" in payload.text:
                    print("[+] elfinder :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '<title>Roxy file manager' in payload.text:
                    print("[+] Roxy file manager :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif 'scripts/filemanager.php' in payload.text:
                    print("[+] SimoFM :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif '/css/index.php?type=fm&theme=fm&package=index_css' in payload.text:
                    print("[+] MCFileManager :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif 'js/moxman.loader.min.js' in payload.text:
                    print("[+] Moxiemanager :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif 'CKEDITOR.editorConfig' in payload.text:
                    print("[+] Ckeditor - Config :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
                elif site.endswith('Util/PHP/eval-stdin.php'):
                    print("[+] PHP Unit :: " + site)
                    open('result/result.txt', 'a').write(site+'\n')
            elif payload.history:
                for resp in payload.history:
                    if any(cms not in payload.text for cms in ['OpenCart', 'Django']):
                        if resp.status_code == 302:
                            if any(login in payload.url for login in ['/login', '/dashboard', 'user']):
                                print("[+] Admin 302 :: " + payload.url)
                                open('result/result.txt', 'a').write(payload.url+'\n')
                                break
                        elif any(site.endswith(admin) for admin in pathAdmin):
                            if resp.url == f"{site}/":
                                print("[+] Admins Path :: " + resp.url)
                                open('result/result.txt', 'a').write(payload.url+'\n')
                                break
                        elif any(site.endswith(path) for path in paths):
                            if resp.url == f"{site}/":
                                print("[+] Bug Path :: " + resp.url)
                                open('result/result.txt', 'a').write(resp.url+'\n')
                                break
                # else:
                #     payload2 = requests.get(site, headers=header, verify=False, timeout=30, allow_redirects=True)
                #     if 
                #     elif any(login in payload2.url for login in ['/login', '/dashboard']):
                #         print(GREEN + "[+] ADMIN :: " + site + RESET)
                #         open('result/result.txt', 'a').write(site+'\n')
                #     if 'jQuery' in payload2.text:
                #         print(GREEN + "[+] WordPress :: " + site + RESET)
                #         open('result/WordPress.txt', 'a').write(site+'\n')
                #         break
                #     elif 'window.Joomla' in payload2.text:
                #         print("[+] Joomla :: " + site)
                #         open('result/Joomla.txt', 'a').write(site+'\n')
                #         break
                #     else:
                #         print("[+] UNKNOWN :: " + site)
                #         open('result/Unknown.txt', 'a').write(site+'\n')
            # else:
            #     print("[+] UNKNOWN :: " + site)
            #     open('result/Unknown1.txt', 'a').write(site+'\n')
        else:
            # print("[+] UNKNOWN :: " + site)
            open('result/Unknown2.txt', 'a').write(site+'\n')
    except Exception as e:
        open('result/DeadSite.txt', 'a').write(site+'\n')
        # print(RED + "[+] DEAD SITE :: " + site + " (" + str(e) + ")" + RESET)

def multixcms():
    sitex = open(input(RED + 'List : ' + WHITE), 'r').readlines()
    td = input("Threads : ")  
    pool = ThreadPool(int(td))
    pool.map(first, sitex)
    print(f"\n{GREEN}[+] :: First is Done :: {RESET}")

    print(f"\n{GREEN}[+] :: Beginning Scan For Valid Bug :: {RESET}\n")
    with open("result2/bugs.txt", "r") as file:
        lines = [line.strip() for line in file]
        pool.map(secc, lines)
    pool.close()
    pool.join()

multixcms()