import requests
import subprocess
import urllib3
import os
import random
import sys
import time
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore

init()
urllib3.disable_warnings()

# Now regular ANSI codes should work, even in Windows
RED = Fore.RED
RESET = Fore.RESET
WHITE = Fore.WHITE
GREEN = Fore.GREEN  # Added green color

def print_logo():
    clear = "\x1b[0m"
    colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]

    x = """

            FILTER BUGS (ACTIVE)
            BY CHAELTHEEX3C
                           
                          
                                                        
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.02)

print_logo()

if not os.path.exists("result4/"):
    os.makedirs("result4/", 0o755)

header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

def lightxcms(site):
    site = site.strip()
    site = site.replace('\n', '').replace('\r', '')

    admins = [  "/admin",
                "/adm",
                "/backend",
                "/panel",
                "/cms",
                "/administrator",
                "/administration",
                "/backoffice",
                "/back",
                "/dashboard",
                "/user",
                "/login",
                "/admin1",
                "/admin2",
                "/amministrazione",
                "/gestion",
                "/area",
                "/areas",
                "/master",
                "/manager"
        ]

    try:
        payload = requests.get(site, headers=header, timeout=30, allow_redirects=True, verify=False)
        if payload.status_code == 200:
            if "<title>FileManager</title>" in payload.text:
                print("[+] RFM1 :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif "<title>Responsive FileManager</title>" in payload.text:
                print("[+] RFM2 :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif 'KCFinder:' in payload.text:
                print("[+] KCFinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif 'open_manager_upload_path' in payload.text:
                print("[+] OpenManager :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '{"files' in payload.text:
                print("[+] JFU :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '<title>FCKeditor -' in payload.text:
                print("[+] FCKeditor :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '<pre>Array' in payload.text:
                print("[+] Ajax File Manager :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '<title>Ajax File Manager' in payload.text:
                print("[+] Ajax File Manager :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '{"error":["errUnknownCmd' in payload.text:
                print("[+] elfinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif "url : '/efconnect'" in payload.text:
                print("[+] elfinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '<title>elFinder' in payload.text:
                print("[+] elfinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif "url: 'php/connector_minimal.php'" in payload.text:
                print("[+] elfinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif "url: 'php/connector.minimal.php'" in payload.text:
                print("[+] elfinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif "url : 'php/connector.php'" in payload.text:
                print("[+] elfinder :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '<title>Roxy file manager' in payload.text:
                print("[+] Roxy file manager :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif '<title>File Manager' in payload.text:
                print("[+] SimoFM :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif 'href="../../css/index.php?type=fm&theme=fm&package=index_css' in payload.text:
                print("[+] MCFileManager :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif 'src="js/moxman.loader.min.js' in payload.text:
                print("[+] Moxiemanager :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif 'CKEDITOR.editorConfig' in payload.text:
                print("[+] Ckeditor - Config :: " + site)
                open('result4/bugs.txt', 'a').write(site+'\n')
            elif any(site.endswith(admin) for admin in admins):
                if any(login in payload.url for login in ['/login', '/dashboard']):
                    print("[+] Admin :: " + payload.url)
                    # open('result4/bugs.txt', 'a').write(site+'\n')
                elif payload.url == site + "/":
                    print("[+] Path Admin or Bug :: " + payload.url)
                    # open('result4/bugs.txt', 'a').write(site+'\n')
            # elif 'laravel_session' in payload.text:
            #     print("[+] Laravel :: " + site)
            #     open('result4/bugs.txt', 'a').write(site+'\n')
            # elif 'laravel_session' in payload.text:
            #     print("[+] Laravel :: " + site)
            #     open('result4/bugs.txt', 'a').write(site+'\n')
            # elif 'laravel_session' in payload.text:
            #     print("[+] Laravel :: " + site)
            #     open('result4/bugs.txt', 'a').write(site+'\n')
            # elif 'laravel_session' in payload.text:
            #     print("[+] Laravel :: " + site)
            #     open('result4/bugs.txt', 'a').write(site+'\n')
            # else:
            #     for admin in ['/login', '/dashboard']:
            #     payload2 = requests.get(site, headers=header, verify=False, timeout=30, allow_redirects=True)
            #     if 
            #     elif any(login in payload2.url for login in ['/login', '/dashboard']):
            #         print(GREEN + "[+] ADMIN :: " + site + RESET)
            #         open('result4/bugs.txt', 'a').write(site+'\n')
            #     if 'jQuery' in payload2.text:
            #         print(GREEN + "[+] WordPress :: " + site + RESET)
            #         open('result4/WordPress.txt', 'a').write(site+'\n')
            #         break
            #     elif 'window.Joomla' in payload2.text:
            #         print("[+] Joomla :: " + site)
            #         open('result4/Joomla.txt', 'a').write(site+'\n')
            #         break
            #     else:
            #         print("[+] UNKNOWN :: " + site)
            #         open('result4/Unknown.txt', 'a').write(site+'\n')
        else:
            # print("[+] UNKNOWN :: " + site)
            open('result4/Unknown.txt', 'a').write(site+'\n')
    except Exception as e:
        open('result4/DeadSite.txt', 'a').write(site+'\n')
        # print(RED + "[+] DEAD SITE :: " + site + " (" + str(e) + ")" + RESET)
def multixcms():
    sitex = open(input(RED + 'List : ' + WHITE), 'r').readlines()
    td = input("Threads : ")  
    pool = ThreadPool(int(td))
    pool.map(lightxcms, sitex)
    pool.close()
    pool.join()

multixcms()