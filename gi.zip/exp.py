import sys
import os
import time
from concurrent.futures import ThreadPoolExecutor
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore

RED = Fore.RED
RESET = Fore.RESET
WHITE = Fore.WHITE
GREEN = Fore.GREEN

def tigaratus(line):
    valid_rc = ['| 300 |', '| 301 |', '| 303 |', '| 304 |', '| 305 |', '| 306 |', '| 307 |', '| 308 |', '| 309 |']
    for rc in valid_rc:
        if rc in line:
            return True
    return False

def duaratus(line):
    valid_endpoints = ['.php', '.phtml', '.asp', '.aspx', '/elfinder', '/elfinder/ckeditor', '/filemanager', '/laravel-filemanager', 'config.js', 'server/php']
    for endpoint in valid_endpoints:
        if endpoint in line and '| 200 |' in line:
            return True
    return False

def bugs(line):
    valid_endpoints = [ '.git',
                        '.env',
                        '/filemanager',
                        '/laravel-filemanager',
                        'filemanager/dialog.php',
                        'fm/dialog.php',
                        'responsiveFilemanager/dialog.php',
                        'responsivefilemanager/dialog.php',
                        'ResponsiveFilemanager/dialog.php',
                        'responsiveFileManager/dialog.php',
                        'responsivefileManager/dialog.php',
                        'ResponsiveFileManager/dialog.php',
                        'rfm/dialog.php',
                        'responsive_filemanager/dialog.php',
                        'file-manager/dialog.php',
                        'file_manager/dialog.php',
                        'kfm/',
                        'PGRFileManager.php',
                        'pgrfilemanager/php/upload.php',
                        'pgrfilemanager/php/files.php',
                        'kcfinder/browse.php',
                        'kcfinder/upload.php',
                        'kcf/upload.php',
                        'kcfinder-2.51/upload.php',
                        'kcf/browse.php',
                        'kcfinder-2.51/browse.php',
                        'kcfinder_2.51/browse.php',
                        'kcfinder_2.51/upload.php',
                        'kcfinder_2/browse.php',
                        'kcfinder_2/upload.php',
                        'kcfinder_/browse.php',
                        'kcfinder__/browse.php',
                        'kcfinder___/browse.php',
                        'kcfinder_1/browse.php',
                        'kcfinder_2/browse.php',
                        'kcfinder_3/browse.php',
                        'kcfinder1/browse.php',
                        'kcfinder1.0/browse.php',
                        '_kcfinder/browse.php',
                        '__kcfinder/browse.php',
                        '___kcfinder/browse.php',
                        'kcfinder2/browse.php',
                        'kcfinder2.0/browse.php',
                        '_kcfinder/browse.php',
                        '__kcfinder/browse.php',
                        '___kcfinder/browse.php',
                        'kcfinder3/browse.php',
                        'kcfinder3.0/browse.php',
                        '_kcfinder/browse.php',
                        '__kcfinder/browse.php',
                        '___kcfinder/browse.php',
                        'kcfinder1/browse.php',
                        'kcfinder251/browse.php',
                        'kcfinder2.51/browse.php',
                        'kcfinder_/upload.php',
                        'kcfinder__/upload.php',
                        'kcfinder___/upload.php',
                        'kcfinder_1/upload.php',
                        'kcfinder_2/upload.php',
                        'kcfinder_3/upload.php',
                        'kcfinder1/upload.php',
                        '_kcfinder/upload.php',
                        '__kcfinder/upload.php',
                        '___kcfinder/upload.php',
                        'kcfinder2/upload.php',
                        'kcfinder2.0/upload.php',
                        '_kcfinder/upload.php',
                        '__kcfinder/upload.php',
                        '___kcfinder/upload.php',
                        'kcfinder3/upload.php',
                        'kcfinder3.0/upload.php',
                        '_kcfinder/upload.php',
                        '__kcfinder/upload.php',
                        '___kcfinder/upload.php',
                        'kcfinder1/upload.php',
                        'kcfinder1.0/upload.php',
                        'kcfinder251/upload.php',
                        'kcfinder2.51/upload.php',
                        'connectors/uploadtest.html',
                        'connectors/test.html',
                        'server/php/',
                        'server/php/index.php',
                        'moxiemanager/',
                        'moxiemanager/index.php',
                        'fileman/index.html',
                        'fileman/FileManager.aspx',
                        'openmanager/',
                        'openmanager/index.php',
                        'ckeditor/config.js',
                        'ckeditor1/config.js',
                        'ckeditor2/config.js',
                        'ckeditor3/config.js',
                        'ckeditor4/config.js',
                        'ckeditor5/config.js',
                        '_ckeditor/config.js',
                        '__ckeditor/config.js',
                        '___ckeditor/config.js',
                        'doksoft_uploader/uploader.php',
                        'elfinder/php/connector.php',
                        'elfinder/php/connector.minimal.php',
                        'elfinder/php/connector_minimal.php',
                        'elFinder/php/connector.php',
                        'elFinder/php/connector.minimal.php',
                        'elFinder/php/connector_minimal.php',
                        'elfinder/connectors/php/connector.php',
                        'elfinder/connectors/php/connector.minimal.php',
                        'elfinder/connectors/php/connector_minimal.php',
                        'elFinder/connectors/php/connector.php',
                        'elFinder/connectors/php/connector.minimal.php',
                        'elFinder/connectors/php/connector_minimal.php',
                        'elfinder/connector.php',
                        'elfinder/connector.minimal.php',
                        'elfinder/connector_minimal.php',
                        'elFinder/connector.php',
                        'elFinder/connector.minimal.php',
                        'elFinder/connector_minimal.php',
                        '/php/connector.php',
                        'elfinder.html',
                        'elFinder.html',
                        'elfinder.php',
                        'elFinder.php',
                        '/elfinder',
                        '/elFinder',
                        'elfinder/ckeditor',
                        'elFinder/ckeditor',
                        'elfinder-ckeditor',
                        'elFinder-ckeditor',
                        'PHP/eval-stdin.php',
                        'inc/data.php',
                        'AjexFileManager/',
                        'AjexFileManager/index.html',
                        'fm/index.html',
                        'im/index.html'
                        ]
    for endpoint in valid_endpoints:
        if endpoint in line and '| 200 |' in line:
            return True
    return False

def run_scan3(domain, retries=1, delay=1):
    domain = domain.strip() 
    temp_output_file = f"tmp/f_{domain.replace('/', '_')}.txt"
    ffuf_command = f"ffuf -w ~/tools/path/path3.txt -H \"User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/537.36\" -c -recursion -t 30 -u {domain}/FUZZ -of md -o tmp/f_{domain.replace('/', '_')}.txt -s"
    
    for attempt in range(retries):
        exit_code = os.system(ffuf_command)
        
        if exit_code == 0:
            with open(temp_output_file, "r") as temp_file:
                with open("resultScan.txt", "a") as r_file:
                    for line in temp_file:
                        r_file.write(line)
                        if duaratus(line):
                            with open("r200", "a") as mybshl_file:
                                mybshl_file.write(line)
                        if tigaratus(line):
                            with open("r300", "a") as rrr_file:
                                rrr_file.write(line)
                        if bugs(line):
                            with open("tmp/bugs.txt", "a") as bugs_file:
                                bugs_file.write(line)
            
            os.remove(temp_output_file)
            return True
        else:
            print(f"Attempt {attempt + 1} failed for {domain}, retrying in {delay} seconds...")
            time.sleep(delay)
    
    os.remove(temp_output_file)

    return False

def run_scan1(domain):
    """[+] Scan 1"""
    domain = domain.strip()
    path_file = "/home/chael/tools/path/path1.txt"
    temp_output_file = f"ftemp_{domain.replace('/', '_')}.txt"
    ffuf_command = f"ffuf -w ~/tools/path/path1.txt -H \"User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/537.36\" -c -t 30 -u {domain}/FUZZ -of md -o {temp_output_file} -s"
    
    exit_code = os.system(ffuf_command)
    
    if exit_code == 0:
        with open(temp_output_file, "r") as temp_file:
            with open(path_file, "r") as p_file:
                lines2 = [line.strip() + "/" for line in p_file]
                for line in temp_file:
                    if any(code in line for code in lines2):
                        print(f"[+] {domain} ===> Skip.")
                        os.remove(temp_output_file)
                        return False
    else:
        print(f"[+] Failed.")
    
    os.remove(temp_output_file)

    return True

def run_scan2(domain):
    """[+] Scan 2"""
    domain = domain.strip()
    path_file = "/home/chael/tools/path/path2.txt"
    temp_output_file = f"ftemp_{domain.replace('/', '_')}.txt"
    ffuf_command = f"ffuf -w ~/tools/path/path2.txt -H \"User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/537.36\" -c -t 30 -u {domain}/FUZZ -of md -o {temp_output_file} -s"
    
    exit_code = os.system(ffuf_command)
    
    if exit_code == 0:
        with open(temp_output_file, "r") as temp_file:
            with open(path_file, "r") as p_file:
                lines2 = [line.strip() + "/" for line in p_file]
                for line in temp_file:
                    if any(code in line for code in lines2):
                        print(f"[+] {domain} ===> Skip.")
                        os.remove(temp_output_file)
                        return False
    else:
        print(f"[+] Failed.")
    
    os.remove(temp_output_file)

    return True

def scan_domain(domain):
    if run_scan1(domain):
        if run_scan2(domain):
            if run_scan3(domain):
                print(f"\n[+] {domain.strip()} ===> Scanned.\n")
            else:
                print(f"[+] Failed to connect to {domain.strip()} after multiple attempts.")
                ffuf_command = f"ffuf -w ~/tools/path/path.txt -H \"User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/537.36\" -c -t 30 -recursion -u {domain.strip()}/FUZZ -of md -o tmp/f_{domain.replace('/', '_')}.txt -c"
                os.system(ffuf_command)

                ffuf_output_file = f"tmp/f_{domain.replace('/', '_')}.txt"
                if os.path.exists(ffuf_output_file):
                    with open(ffuf_output_file, "r") as ffuf_file:
                        with open("ff.txt", "a") as f2_file:
                            for line in ffuf_file:
                                f2_file.write(line)
                                if duaratus(line):
                                    with open("mybshl", "a") as mybshl_file:
                                        mybshl_file.write(line)
                    os.remove(ffuf_output_file)
                
        else:
            print(f"[+] {domain.strip()} ===> Skip.")
    else:
        print(f"[+] {domain.strip()} ===> Skip.")

with open("domains", "r") as domains_file:
    domains = [domain.strip() for domain in domains_file]

# with ThreadPoolExecutor(max_workers=25) as executor:
#     executor.map(scan_domain, domains)

def run():
    td = input("Threads : ")
    
    try:
        workers = int(td)  # Konversi input ke integer
        if workers <= 0:
            raise ValueError("Number of threads must be greater than 0.")
    except ValueError as e:
        print(f"Invalid input for threads: {e}")
        return
    
    with ThreadPoolExecutor(max_workers=workers) as executor:
        executor.map(scan_domain, domains)
    

run()
print("\033[92m SCANING FOR BUGS IS DONE \033[0m")  # Menggunakan kode warna ANSI