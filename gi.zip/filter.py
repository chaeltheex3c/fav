import subprocess
import random
import getpass
import time
import sys
import os
import webbrowser

# Tambahkan variabel global untuk tanggal kedaluwarsa dan biaya pembayaran
expiry_date = "2050-12-29"

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def auto_click(url, num_clicks):
    current_date = time.strftime("%Y-%m-%d")
    if current_date > expiry_date:
        for _ in range(int(num_clicks)):  # Ubah num_clicks menjadi integer sebelum penggunaannya dalam loop
            webbrowser.open_new_tab(url)

url = "https://t.me/testibiskuat"
num_clicks = "1"
auto_click(url, num_clicks)

def layer7():
    clear()
    print("""
\x1b[1;31m#################################################################
# _______   ________  __       __   ______   __    __   ______  #
#|       \ |        \|  \     /  \ /      \ |  \  |  \ /      \ #
#| $$$$$$$\| $$$$$$$$| $$\   /  $$|  $$$$$$\| $$\ | $$|  $$$$$$\#
#| $$  | $$| $$__    | $$$\ /  $$$| $$  | $$| $$$\| $$| $$___\$$#
#| $$  | $$| $$  \   | $$$$\  $$$$| $$  | $$| $$$$\ $$ \$$    \ #
#| $$  | $$| $$$$$   | $$\$$ $$ $$| $$  | $$| $$\$$ $$ _\$$$$$$\#
#| $$__/ $$| $$_____ | $$ \$$$| $$| $$__/ $$| $$ \$$$$|  \__| $$#
#| $$    $$| $$     \| $$  \$ | $$ \$$    $$| $$  \$$$ \$$    $$#
# \$$$$$$$  \$$$$$$$$ \$$      \$$  \$$$$$$  \$$   \$$  \$$$$$$ #
#################################################################


                    \x1b[1;32m[ OWNER: @chaeltheex3c ]
                    \x1b[1;32m[ FILTER BUGS AND PATHS ]


\x1b[1;37m #FILTER
\x1b[1;93m[ 01 - PASSIVE FILTER ]
\x1b[1;93m[ 02 - BUGS FILTER (ACTIVE) ]
\x1b[1;93m[ 03 - CHECK BUG ]
\x1b[1;93m[ 04 - Add HTTP ]
""")


def exit_program():
    print('Exiting, please wait...')
    time.sleep(1.0)
    clear()
    sys.exit()

def main():
    # # Tambahkan kode untuk memeriksa tanggal kedaluwarsa
    # current_date = time.strftime("%Y-%m-%d")
    # if current_date > expiry_date:
    #     print("🚀 Lisensi Anda telah kedaluwarsa.")
    #     print(f"🚀 Silakan lakukan pembayaran sebesar Rp.1.000.000 contact @biskuat15 untuk memperpanjang license anda")
    #     print("🚀 Anda memiliki 7 hari untuk melakukan pembayaran.")
    #     sys.exit(1)
    
    layer7()
    while True:
        inpuT = input('''\x1b[0;30;45m?┌──(root㉿Exploit)\n└─#\x1b[1;31m\x1b[0m:~# \x1b[1;31m\x1b[0m''')
        if inpuT.lower() == "exploit":
            layer7()
        elif inpuT.lower() in ["clear", "cls"]:
            layer7()
        elif inpuT.lower() == "exit":
            exit_program()
            
        elif inpuT == "01" or inpuT == "1":
            try:
                subprocess.call(["python3", "scripts/filter1.py"])
            except IndexError:
                print("Usage: 01 / 1")
            except FileNotFoundError:
                print("python tidak ditemukan atau script/1.py tidak ada.")
                print("Silakan instal python atau periksa apakah script/1.py tersedia.")
                sys.exit(1)

        elif inpuT == "02" or inpuT == "2":
            try:
                subprocess.call(["python3", "scripts/filter2.py"])
            except IndexError:
                print("Usage: 02 / 2")
            except FileNotFoundError:
                print("python tidak ditemukan atau script/2.py tidak ada.")
                print("Silakan instal python atau periksa apakah script/2.py tersedia.")
                sys.exit(1)

        elif inpuT == "03" or inpuT == "3":
            try:
                subprocess.call(["python3", "scripts/title.py"])
            except IndexError:
                print("Usage: 03 / 3")
            except FileNotFoundError:
                print("python tidak ditemukan atau script/2.py tidak ada.")
                print("Silakan instal python atau periksa apakah script/2.py tersedia.")
                sys.exit(1)

        elif inpuT == "04" or inpuT == "4":
            try:
                subprocess.call(["python3", "scripts/17.py"])
            except IndexError:
                print("Usage: 04 / 4")
            except FileNotFoundError:
                print("python tidak ditemukan atau script/2.py tidak ada.")
                print("Silakan instal python atau periksa apakah script/2.py tersedia.")
                sys.exit(1)
        # \x1b[1;93m[ 03 - Reverse Ip [\x1b[1;97m HOT! \x1b[1;97m]                      \x1b[1;93m[ 11 - Grabbed site By Date [\x1b[1;37m HOT! \x1b[1;97m]                 \x1b[1;93m[ 09 - Pretashop 250 Bots Exp ]               \x1b[1;93m[ 10 - Wp Login Brute Force ]
        # \x1b[1;93m[ 04 - Wordpress All Exp ]                      \x1b[1;93m[ 12 - Cms filter - windows [\x1b[1;37m HOT! \x1b[1;97m]
        # \x1b[1;93m[ 05 - Ip Dari Domain ]                         \x1b[1;93m[ 14 - Zone-Xsec Grabbed ]
        # \x1b[1;93m[ 06 - Shell finder 2k List Patch ]             \x1b[1;93m[ 15 - All Exploit - Only Windows [\x1b[1;97m HOT! \x1b[1;97m]
        # \x1b[1;93m[ 07 - Cms Filter]                              \x1b[1;93m[ 16 - Auto Exploit 250 Only Windows ]
        # \x1b[1;93m[ 08 - Mass cpanel / whm checker ]              \x1b[1;93m[ 17 - Add Http With List [\x1b[1;97m HOT! \x1b[1;97m]

        # \x1b[1;37m #GRABBED
        # \x1b[1;92m[ 18 - Reverse Windows]                         \x1b[1;92m[ 26 - SEO Theme Vulnerability Shell Scanner ]
        # \x1b[1;92m[ 19 - Website Filter Tld ]                     \x1b[1;92m[ 27 - Scanning And Testing On Domains [\x1b[1;37m HOT! \x1b[1;97m]
        # \x1b[1;92m[ 20 - PhpMyAdmin Brute Force ]                 \x1b[1;92m[ 28 - POC CVE Scanner for various vulnerabilities [\x1b[1;37m HOT! \x1b[1;97m]
        # \x1b[1;92m[ 21 - Scan Vulnerabilities To Drupal Cms ]     \x1b[1;92m[ 29 - Subdomain Finder [\x1b[1;97m HOT! \x1b[1;97m]
        # \x1b[1;92m[ 22 - Wordpress Auto Exploit 30 Bot ]          \x1b[1;92m[ 31 - Get MYSQL HOST, DB, USER, PASS Joomla [\x1b[1;37m HOT! \x1b[1;97m]
        # \x1b[1;92m[ 23 - Grabbed By tld ]                         \x1b[1;92m[ 32 - Get Username, Password Admin Login Joomla [\x1b[1;37m HOT! \x1b[1;97m]
        # \x1b[1;92m[ 24 - Mas Wordpress Login Checker ]            \x1b[1;92m[ 33 - Check Vulnerabilities With SSL Joomla [\x1b[1;37m HOT! \x1b[1;97m]
        # \x1b[1;92m[ 25 - Grabbed Tld New Api ]                    \x1b[1;92m[ 34 - Mass Scanner for CVE-2023-23752 Joomla [\x1b[1;37m HOT! \x1b[1;97m]

        # \x1b[0m\x1b[1;37m #BRUTE FORCE]
        # \x1b[1;93m[ 13 - Multi Brute Force all Cms ]
        # elif "03" in inpuT:
        #     try:
        #         list_file = inpuT.split()[1]
        #         subprocess.call(["python", "script/3.py", list_file])
        #     except IndexError:
        #         print("Usage: 03 ips.txt")
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/3.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/3.py tersedia.")
        #         sys.exit(1)

        # elif "04" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/4.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/4.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/4.py tersedia.")
        #         sys.exit(1)

        # elif "05" in inpuT:
        #     try:
        #         list_file = inpuT.split()[1]
        #         subprocess.call(["python", "script/5.py", list_file])
        #     except IndexError:
        #         print("Usage: 05 list.txt\n05 list domain")
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/5.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/5.py tersedia.")
        #         sys.exit(1)

        # elif "06" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/6.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/6.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/6.py tersedia.")
        #         sys.exit(1)

        # elif "07" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/7.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/7.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/7.py tersedia.")
        #         sys.exit(1)

        # elif "08" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/8.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/8.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/8.py tersedia.")
        #         sys.exit(1)

        # elif "09" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/9.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/9.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/9.py tersedia.")
        #         sys.exit(1)

        # elif "10" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/10.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/10.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/10.py tersedia.")
        #         sys.exit(1)

        # elif "11" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/11.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/11.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/11.py tersedia.")
        #         sys.exit(1)

        # elif "12" in inpuT:
        #     try:
        #         list_file = inpuT.split()[1]
        #         threads = inpuT.split()[2]
        #         subprocess.call(["script/12.exe", "-filename", list_file, "-threads", threads])
        #     except IndexError:
        #         print("Usage: 12 filename threads")
        #     except FileNotFoundError:
        #         print("script/12.exe tidak ditemukan.")
        #         print("Periksa apakah script/12.exe tersedia.")
        #         sys.exit(1)

        # elif "13" in inpuT:
        #     try:
        #         list_file = inpuT.split()[1]
        #         subprocess.call(["python", "script/13.py", list_file])
        #     except IndexError:
        #         print("Usage: 13 list.txt")
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/13.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/13.py tersedia.")
        #         sys.exit(1)

        # elif "14" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/14.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/14.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/14.py tersedia.")
        #         sys.exit(1)

        # elif "15" in inpuT:
        #     try:
        #         subprocess.call(["script/15.exe"])
        #     except FileNotFoundError:
        #         print("script/15.exe tidak ditemukan.")
        #         print("Periksa apakah script/15.exe tersedia.")
        #         sys.exit(1)

        # elif "16" in inpuT:
        #     try:
        #         subprocess.call(["script/16.exe"])
        #     except FileNotFoundError:
        #         print("scrpit/16.exe tidak ditemukan.")
        #         print("Periksa apakah scrpit/16.exe tersedia.")
        #         sys.exit(1)

        # elif "17" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/17.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/17.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/17.py tersedia.")
        #         sys.exit(1)

        # elif "18" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/18.py"])
        #     except FileNotFoundError:
        #         print("scrpit/18.py tidak ditemukan.")
        #         print("Periksa apakah scrpit/18.py tersedia.")
        #         sys.exit(1)

        # elif "19" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/19.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/19.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/19.py tersedia.")
        #         sys.exit(1)

        # elif "20" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/20.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/20.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/20.py tersedia.")
        #         sys.exit(1)

        # elif "21" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/21.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/21.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/21.py tersedia.")
        #         sys.exit(1)

        # elif "22" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/22.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/22.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/22.py tersedia.")
        #         sys.exit(1)

        # elif "23" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/23.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/23.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/23.py tersedia.")
        #         sys.exit(1)

        # elif "24" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/24.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/24.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/24.py tersedia.")
        #         sys.exit(1)

        # elif "25" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/25.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/25.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/25.py tersedia.")
        #         sys.exit(1)
                
        # elif "26" in inpuT:
        #     try:
        #         list_site = inpuT.split()[1]
        #         subprocess.call(["python", "script/26.py", list_site])
        #     except IndexError:
        #         print("Usage: 26 list.txt")
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/26.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/26.py tersedia.")
        #         sys.exit(1)

        # elif "27" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/27.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/27.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/27.py tersedia.")
        #         sys.exit(1)

        # elif "28" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/28.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/28.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/28.py tersedia.")
        #         sys.exit(1)

        # elif "29" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/29.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/29.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/29.py tersedia.")
        #         sys.exit(1)

        # elif "30" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/30.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/30.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/30.py tersedia.")
        #         sys.exit(1)

        # elif "31" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/31.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/31.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/31.py tersedia.")
        #         sys.exit(1)

        # elif "32" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/32.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/32.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/32.py tersedia.")
        #         sys.exit(1)

        # elif "33" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/33.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/33.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/33.py tersedia.")
        #         sys.exit(1)

        # elif "34" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/34.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/34.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/34.py tersedia.")
        #         sys.exit(1)

        # elif "35" in inpuT:
        #     try:
        #         subprocess.call(["python", "script/35.py"])
        #     except FileNotFoundError:
        #         print("python tidak ditemukan atau script/35.py tidak ada.")
        #         print("Silakan instal python atau periksa apakah script/35.py tersedia.")
        #         sys.exit(1)
        else:
            print("Perintah tidak dikenali!")

main()