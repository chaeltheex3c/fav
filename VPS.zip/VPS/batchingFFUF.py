import time
import os
import subprocess

BATCH_SIZE = 200
DELAY_SECONDS = 5
SOURCE_FILE = 'domains'
TEMP_FILE = 'batch_temp_ffuf_file.txt'

def read_lines(file_path):
    with open(file_path, 'r', encoding='utf8') as f:
        return f.read().splitlines()

def run_batch(batch_data):
    with open(TEMP_FILE, 'w', encoding='utf8') as f:
        f.write('\n'.join(batch_data))
    
    try:
        # Jalankan dengan timeout 10 menit (600 detik)
        subprocess.run(['python3', 'exp.py', TEMP_FILE, str(BATCH_SIZE)], timeout=720)
    except subprocess.TimeoutExpired:
        print("[!] Batch terminated: exceeded 720s limit.")

def main():
    all_lines = read_lines(SOURCE_FILE)
    total = len(all_lines)
    print(f"[+] Total: {total} URLs")

    for i in range(0, total, BATCH_SIZE):
        batch = all_lines[i:i+BATCH_SIZE]
        print(f"[+] Processing batch {i} - {i + len(batch) - 1}")
        run_batch(batch)
        if i + BATCH_SIZE < total:
            print(f"[+] Sleeping for {DELAY_SECONDS // 60} minutes...\n")
            time.sleep(DELAY_SECONDS)

    # Hapus file sementara
    if os.path.exists(TEMP_FILE):
        os.remove(TEMP_FILE)
    print("[+] All batches completed.")

if __name__ == '__main__':
    main()
    print("[+] Selesai .")
