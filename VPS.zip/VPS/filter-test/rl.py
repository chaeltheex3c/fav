def remove_lines_with_word(input_file, output_file, word):
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            if word not in line:
                outfile.write(line)

def main():
    input_file = 'list'
    output_file = 'result'
    word_to_remove = input("[+] INPUT WORD: ")

    remove_lines_with_word(input_file, output_file, word_to_remove)

    print(f"[+] '{word_to_remove}' REMOVED !!! ===> '{output_file}'.")

if __name__ == '__main__':
    main()
